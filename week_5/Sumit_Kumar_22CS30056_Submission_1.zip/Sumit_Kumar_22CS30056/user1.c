/*
=====================================
Assignment 4 Submission
Name: Sumit Kumar
Roll number: 22CS30056
Link of the pcap file: https://drive.google.com/file/d/1oVlMXRj64Tm5PP4Hwitug86i2ukzKnng/view?usp=sharing
=====================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include "ksocket.h"

#define FILE_NAME "sumit.txt"
#define SRC_IP "127.0.0.1"
#define DEST_IP "127.0.0.1"
#define SRC_PORT 2000
#define DEST_PORT 3000

int main(int argc, char *argv[])
{   
     if (argc != 5)
    {
        fprintf(stderr, "Usage: %s <local_ip> <local_port> <remote_ip> <remote_port>\n", argv[0]);
        exit(1);
    }

    int sockfd = k_socket(AF_INET, SOCK_KTP, 0);
    if (sockfd < 0)
    {
        perror("Socket creation failed");
        exit(0);
    }
    struct sockaddr_in user1addr;
    struct sockaddr_in user2addr;
    user1addr.sin_family = AF_INET;
    user2addr.sin_family = AF_INET;

    user1addr.sin_addr.s_addr = inet_addr(SRC_IP);
    user2addr.sin_addr.s_addr = inet_addr(DEST_IP);
    user1addr.sin_port = htons(atoi(argv[2]));
    user2addr.sin_port = htons(atoi(argv[4]));

    if (k_bind(sockfd, (struct sockaddr *)&user1addr, (struct sockaddr *)&user2addr) < 0)
    {
        perror("Socket Binding failed");
        exit(0);
    }
    int fd = open(FILE_NAME, O_RDONLY);
    char data[MAX_MSG_SIZE];
    int cnt = 0;
    while (1)
    {
        for (int i = 0; i < MAX_MSG_SIZE; i++)
        {
            data[i] = '\0';
        }
        int bytes_recv = read(fd, data, MAX_MSG_SIZE);
        int n = 0;
        while (n <= 0)
        {
            n = k_sendto(sockfd, data, MAX_MSG_SIZE, 0, (struct sockaddr *)&user2addr, sizeof(user2addr));
        }
        printf("Data chunk - %d sent successfully\n", ++cnt);
        if (bytes_recv < MAX_MSG_SIZE)
            break;
    }
    close(fd);
}