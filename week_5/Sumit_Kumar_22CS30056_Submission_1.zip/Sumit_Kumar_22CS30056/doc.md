# KTP Documentation

## **Data Structures Used in `ksocket.c`**

### **1. Struct `msg`**
The `msg` structure represents a message to be transmitted, stored in send or receive buffers. It encapsulates essential information such as the sequence number, last transmission time, and data.

**Components:**
- `int seq_no`  			— Sequence number of the message.
- `time_t last_time`  	— Timestamp indicating the last time the message was sent across the network. It is set to `-2` if the slot is empty and `-1` if the data was never sent.
- `char data[512]`  	— Data part of the message, with a size of 512 bytes.

### **2. Struct `window`**
The `window` structure represents the sender window in the communication context. It is implemented as a circular queue to manage message transmission efficiently.

**Components:**
- `int first_idx`  	— Index of the first end marker in the sender buffer.
- `int last_idx`  	— Index of the last end marker in the sender buffer.
- `int first_msg`  	— Sequence number of the first message in the window.
- `int last_msg`  	— Sequence number of the last message in the window.
- `int entry`  		— Position where data will be inserted during an `k_sendto` call.

### **3. Struct `ktp_sock`**
The `ktp_sock` structure represents the basic entry of a socket.  It contains attributes and buffers required for reliable message transmission over UDP sockets.

**Components:**
- `int free`  						— Indicates availability of the socket entry (`1` for free, `0` for in-use).
- `pid_t process_id`  		— Process ID associated with the socket.
- `int udp_socket`  			— File descriptor for the underlying UDP socket.
- `struct sockaddr_in dest_addr`  	— Destination address for communication.
- `struct msg send_buff[SEND_BUFFER_SIZE]`  	— Array of message structures representing the send buffer.
- `struct msg recv_buff[RECV_BUFFER_SIZE]`  	— Array of message structures representing the receive buffer.
- `struct window swnd`  		— Sender window data structure.
- `int rwnd[RECV_BUFFER_SIZE]`  	— Array representing the receive window for flow control.

### **4. Struct `SOCK_INFO`**
The `SOCK_INFO` structure facilitates communication between the initialization process and a user process in ktp. It enables exchange of essential socket-related information during `k_socket` and `k_bind` operations.

**Components:**
- `int status`  					— Indicates the status of the socket (`0` for `socket()`, `1` for `bind()`).
- `int ktp_id`  					— Table index associated with the ktp socket.
- `int internetFamily`  		— Specifies the address family (IPv4, IPv6).
- `int flag`  						— Additional control or status flag.
- `struct sockaddr_in src_addr`  	— Source address associated with the socket for binding.
- `int errnum`  				— Return value of system calls.
- `int err_no`  				— Global error number (`errno`).

---

## **Data Structures Used in `initksocket.c`**

- `Last_inorder`  	— Sequence number of the last message received in order.
- `Last_ack`  		— Sequence number of the last acknowledged message.
- `Last_seq_no_send`  	— Last sequence number inserted into the send buffer by `k_sendto()`.
- `Last_seq_no_recv`  	— Last sequence number retrieved from the receive buffer by `k_recvfrom()`.
- `no_space`  		— Flag indicating if the receive buffer is full (`1` means no space).
- `ack_timer`  		— Timer set for special ACKs sent when `no_space` changes from `1` to `0`.

### **Table**
The `Table` is a data structure that manages multiple ktp sockets. It serves as a centralized repository for storing socket-specific information.

**Structure:**
- **Type:** Pointer to an array of `ktp_sock` structures.
- **Elements:** Each element represents an ktp socket with state, configuration, and communication parameters.

---

## **Functions Used in the Program**

### **Message Handling Functions**
- `dropMessage(float prob)`  	— Simulates message loss based on probability `prob`.
- `cmp(int a, int b)`  	— Compares two sequence numbers, handling wrap-around conditions.
- `calEmptySpace(int idx)`  	— Computes empty slots in the receive buffer.
- `firstEmptySlot(int idx)`  	— Finds the first empty slot in the receive buffer.
- `RECV(int idx)`  	— Receives messages from the UDP socket and processes ACKs or data messages.
- `sendACK(int i, int x, int y)`  	— Sends ACK messages with sequence numbers from `x` to `y`.
- `sendDATA(int i, int j)`  	— Sends a data message from the send buffer at index `j`.

### **Shared Memory and Synchronization**
- `createTable()`  	— Creates a shared memory segment for the ktp socket table.
- `createSHM()`  	— Creates shared memory for various ktp variables.
- `initSemaphore(int *semid, int key, int initValue)`  	— Initializes a semaphore.
- `destroySemaphore(int *semid)`  	— Destroys a semaphore.
- `ATTACH()`  	— Initializes and attaches shared memory segments and semaphores.
- `DETACH()`  	— Cleans up shared memory and semaphore resources.

---

## **Average Number of Transmissions vs Failure Probability (p)**

| Failure Probability (p) | Number of Transmissions | Transmissions per Message |
|------------------------|----------------------|-------------------------|
| 0.00                   | 134                  | 1.0000                  |
| 0.05                   | 138                  | 1.0299                  |
| 0.10                   | 151                  | 1.1269                  |
| 0.15                   | 168                  | 1.2537                  |
| 0.20                   | 199                  | 1.4851                  |
| 0.25                   | 218                  | 1.6269                  |
| 0.30                   | 246                  | 1.8358                  |
| 0.35                   | 269                  | 2.0075                  |
| 0.40                   | 290                  | 2.1642                  |
| 0.45                   | 316                  | 2.3582                  |
| 0.50                   | 352                  | 2.6269                  |

---
