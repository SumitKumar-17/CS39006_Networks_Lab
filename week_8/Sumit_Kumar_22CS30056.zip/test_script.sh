#!/bin/bash

# Colors for better output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=================================${NC}"
echo -e "${BLUE}Task Queue System Test Script${NC}"
echo -e "${BLUE}=================================${NC}"

# Create logs directory
mkdir -p test_logs
echo -e "${YELLOW}Created test_logs directory for all log files${NC}"

# Check if executables exist
if [ ! -f "./task_queue_server" ]; then
    echo -e "${RED}Error: task_queue_server executable not found!${NC}"
    echo -e "${YELLOW}Compiling server code...${NC}"
    gcc task_queue_server.c -o task_queue_server
    if [ $? -ne 0 ]; then
        echo -e "${RED}Failed to compile task_queue_server.c${NC}"
        exit 1
    fi
fi

if [ ! -f "./worker_client" ]; then
    echo -e "${RED}Error: worker_client executable not found!${NC}"
    echo -e "${YELLOW}Compiling client code...${NC}"
    gcc worker_client.c -o worker_client
    if [ $? -ne 0 ]; then
        echo -e "${RED}Failed to compile worker_client.c${NC}"
        exit 1
    fi
fi

# Create a tasks file with some arithmetic operations
echo -e "${YELLOW}Creating test tasks file...${NC}"
cat > test_logs/tasks.txt << EOF
10 + 20
30 - 15
5 * 6
100 / 4
25 + 37
42 - 18
7 * 9
81 / 9
50 + 50
12 * 12
200 / 8
64 + 36
90 - 45
3 * 21
150 / 6
EOF

echo -e "${GREEN}Created test_logs/tasks.txt with 15 arithmetic tasks${NC}"

# Start the server in the background
echo -e "${YELLOW}Starting the task queue server...${NC}"
./task_queue_server test_logs/tasks.txt > test_logs/server_log.txt 2>&1 &
SERVER_PID=$!

# Give server time to initialize
sleep 2

# Check if server started successfully
if ! ps -p $SERVER_PID > /dev/null; then
    echo -e "${RED}Server failed to start. Check test_logs/server_log.txt for details.${NC}"
    cat test_logs/server_log.txt
    exit 1
fi

# Check if server is listening on the expected port
netstat -tuln | grep 8080 > /dev/null
if [ $? -ne 0 ]; then
    echo -e "${YELLOW}Warning: Server doesn't appear to be listening on port 8080${NC}"
    echo -e "${YELLOW}Checking server log for errors...${NC}"
    cat test_logs/server_log.txt | tail -20
else
    echo -e "${GREEN}Server is listening on port 8080${NC}"
fi

if ! ps -p $SERVER_PID > /dev/null; then
    echo -e "${RED}Server failed to start. Check server_log.txt for details.${NC}"
    exit 1
fi

echo -e "${GREEN}Server started with PID: $SERVER_PID${NC}"

# Function to start a client and save its output
start_client() {
    local client_num=$1
    echo -e "${YELLOW}Starting worker client $client_num...${NC}"
    ./worker_client > test_logs/client_${client_num}_log.txt 2>&1 &
    echo $!
}

# Start multiple clients
CLIENT_PIDS=()
for i in {1..5}; do
    pid=$(start_client $i)
    CLIENT_PIDS+=($pid)
    # Small delay between client starts
    sleep 0.5
done

echo -e "${GREEN}Started 5 worker clients with PIDs: ${CLIENT_PIDS[@]}${NC}"

# Monitor progress
echo -e "${YELLOW}Monitoring for 15 seconds...${NC}"
for i in {1..15}; do
    echo -e "${BLUE}Test running: $i seconds elapsed${NC}"
    sleep 1
    
    # Check if server is still running
    if ! ps -p $SERVER_PID > /dev/null; then
        echo -e "${GREEN}Server has completed all tasks and shut down.${NC}"
        break
    fi
done

# Check if clients are still running
ACTIVE_CLIENTS=0
for pid in "${CLIENT_PIDS[@]}"; do
    if ps -p $pid > /dev/null 2>&1; then
        ACTIVE_CLIENTS=$((ACTIVE_CLIENTS+1))
    fi
done

echo -e "${BLUE}Active clients: $ACTIVE_CLIENTS${NC}"

# Test if a client can request multiple tasks in sequence
echo -e "${YELLOW}Testing if a single client can request multiple tasks sequentially...${NC}"
./worker_client > test_logs/client_multiple_tasks.txt 2>&1 &
MULTIPLE_TASK_CLIENT_PID=$!
sleep 12
kill -INT $MULTIPLE_TASK_CLIENT_PID 2>/dev/null

# Test if client can't request a new task before completing current one
echo -e "${YELLOW}Testing if client cannot request new task before completing current...${NC}"
# This is difficult to test directly with bash, but we can check server logs later

# Test client exit command
echo -e "${YELLOW}Testing client exit command handling...${NC}"
./worker_client > test_logs/client_exit_test.txt 2>&1 &
EXIT_CLIENT_PID=$!
sleep 7
echo -e "${YELLOW}Sending SIGINT to client with PID $EXIT_CLIENT_PID to trigger exit command${NC}"
kill -INT $EXIT_CLIENT_PID 2>/dev/null

# Test server acknowledgment response
echo -e "${YELLOW}Testing server acknowledgment handling...${NC}"
./worker_client > test_logs/client_ack_test.txt 2>&1 &
ACK_CLIENT_PID=$!
sleep 10
kill -INT $ACK_CLIENT_PID 2>/dev/null
grep "Server acknowledgment" test_logs/client_ack_test.txt
if [ $? -eq 0 ]; then
    echo -e "${GREEN}Server acknowledgment test passed${NC}"
else
    echo -e "${RED}Server acknowledgment test failed${NC}"
fi

# Test timeout behavior by starting a client and killing it without completion
echo -e "${YELLOW}Testing timeout behavior...${NC}"
./worker_client > test_logs/client_timeout.txt 2>&1 &
TIMEOUT_CLIENT_PID=$!
sleep 2
kill -9 $TIMEOUT_CLIENT_PID 2>/dev/null
echo -e "${YELLOW}Killed client with PID $TIMEOUT_CLIENT_PID to test timeout handling${NC}"
sleep 12  # Wait for server's timeout mechanism

# Test invalid task format handling
echo -e "${YELLOW}Testing invalid task format handling...${NC}"
# Temporarily create a test file with an invalid task
echo "THIS_IS_NOT_A_VALID_TASK" > test_logs/invalid_tasks.txt
./task_queue_server test_logs/invalid_tasks.txt > test_logs/invalid_task_server.txt 2>&1 &
INVALID_SERVER_PID=$!
sleep 2
./worker_client > test_logs/client_invalid_task.txt 2>&1 &
INVALID_CLIENT_PID=$!
sleep 5
kill -INT $INVALID_CLIENT_PID 2>/dev/null
kill -INT $INVALID_SERVER_PID 2>/dev/null

# Test division by zero error handling
echo -e "${YELLOW}Testing division by zero error handling...${NC}"
echo "10 / 0" > test_logs/division_zero.txt
./task_queue_server test_logs/division_zero.txt > test_logs/division_zero_server.txt 2>&1 &
DIV_ZERO_SERVER_PID=$!
sleep 2
./worker_client > test_logs/client_div_zero.txt 2>&1 &
DIV_ZERO_CLIENT_PID=$!
sleep 5
kill -INT $DIV_ZERO_CLIENT_PID 2>/dev/null
kill -INT $DIV_ZERO_SERVER_PID 2>/dev/null

# Wait a bit for the server to handle the disconnection
sleep 5

# Clean up any remaining clients
for pid in "${CLIENT_PIDS[@]}"; do
    if ps -p $pid > /dev/null 2>&1; then
        echo -e "${YELLOW}Terminating client with PID $pid${NC}"
        kill -INT $pid 2>/dev/null
    fi
done

# Give clients time to exit gracefully
sleep 2

# Kill any remaining clients forcefully
for pid in "${CLIENT_PIDS[@]}"; do
    if ps -p $pid > /dev/null 2>&1; then
        echo -e "${RED}Forcefully killing client with PID $pid${NC}"
        kill -9 $pid 2>/dev/null
    fi
done

# Check if server is still running, and kill it if it is
if ps -p $SERVER_PID > /dev/null 2>&1; then
    echo -e "${YELLOW}Server is still running. Terminating...${NC}"
    kill -INT $SERVER_PID
    sleep 2
    
    # If still running, force kill
    if ps -p $SERVER_PID > /dev/null 2>&1; then
        echo -e "${RED}Forcefully killing server${NC}"
        kill -9 $SERVER_PID
    fi
else
    echo -e "${GREEN}Server has already terminated normally.${NC}"
fi

# Analyze logs
echo -e "${BLUE}=================================${NC}"
echo -e "${BLUE}Test Results${NC}"
echo -e "${BLUE}=================================${NC}"

echo -e "${YELLOW}Checking server log:${NC}"
COMPLETED_TASKS=$(grep "Task .* completed" test_logs/server_log.txt | wc -l)
ASSIGNED_TASKS=$(grep "Assigned task" test_logs/server_log.txt | wc -l)
RETURNED_TASKS=$(grep "Task .* returned to queue" test_logs/server_log.txt | wc -l)
CONNECTIONS=$(grep "New connection" test_logs/server_log.txt | wc -l)
DISCONNECTIONS=$(grep "Client .* disconnected" test_logs/server_log.txt | wc -l)
CHILD_PROCESSES=$(grep "Child process" test_logs/server_log.txt | wc -l)
EXIT_REQUESTS=$(grep "Client .* requested to exit" test_logs/server_log.txt | wc -l)

echo -e "  - ${GREEN}Tasks in test file: 15${NC}"
echo -e "  - ${GREEN}Completed tasks: $COMPLETED_TASKS${NC}"
echo -e "  - ${GREEN}Assigned tasks: $ASSIGNED_TASKS${NC}"
echo -e "  - ${GREEN}Tasks returned to queue: $RETURNED_TASKS${NC}"
echo -e "  - ${GREEN}Client connections: $CONNECTIONS${NC}"
echo -e "  - ${GREEN}Client disconnections: $DISCONNECTIONS${NC}"
echo -e "  - ${GREEN}Child processes created: $CHILD_PROCESSES${NC}"
echo -e "  - ${GREEN}Exit requests: $EXIT_REQUESTS${NC}"

# Check client logs
for i in {1..5}; do
    echo -e "${YELLOW}Checking client $i log:${NC}"
    TASKS_RECEIVED=$(grep "Task:" test_logs/client_${i}_log.txt | wc -l)
    RESULTS_SENT=$(grep "Calculated result:" test_logs/client_${i}_log.txt | wc -l)
    ACK_RECEIVED=$(grep "Server acknowledgment:" test_logs/client_${i}_log.txt | wc -l)
    RETRIES=$(grep "retrying" test_logs/client_${i}_log.txt | wc -l)
    
    echo -e "  - ${GREEN}Tasks received: $TASKS_RECEIVED${NC}"
    echo -e "  - ${GREEN}Results sent: $RESULTS_SENT${NC}"
    echo -e "  - ${GREEN}Acknowledgments received: $ACK_RECEIVED${NC}"
    echo -e "  - ${GREEN}Retry attempts: $RETRIES${NC}"
done

# Check multiple task client
MULTIPLE_TASKS_RECEIVED=$(grep "Task:" test_logs/client_multiple_tasks.txt | wc -l)
echo -e "${YELLOW}Multiple task client received: $MULTIPLE_TASKS_RECEIVED tasks${NC}"

# Check exit handling
EXIT_HANDLED=$(grep "Goodbye" test_logs/client_exit_test.txt | wc -l)
echo -e "${YELLOW}Exit command test - Goodbye messages received: $EXIT_HANDLED${NC}"

# Check timeout handling in server log
sleep 2 # Give the server time to log timeout-related messages
TIMEOUT_HANDLED=$(grep "Task .* returned to queue" test_logs/server_log.txt | wc -l)
echo -e "${YELLOW}Tasks returned to queue (potentially from timeouts): $TIMEOUT_HANDLED${NC}"

# Test for concurrent task processing
echo -e "${YELLOW}Analyzing concurrent task processing...${NC}"
CONCURRENT_CLIENTS=$(grep "Child process .* handling client" test_logs/server_log.txt | sort | uniq | wc -l)
MAX_CONCURRENT=$(grep "Spawned child process" test_logs/server_log.txt | sort -r | head -1 | grep -oE "client [0-9]+" | cut -d' ' -f2)

echo -e "${GREEN}Concurrent clients detected: $CONCURRENT_CLIENTS${NC}"
if [ ! -z "$MAX_CONCURRENT" ]; then
    echo -e "${GREEN}Highest client ID: $MAX_CONCURRENT${NC}"
else
    echo -e "${RED}Could not determine highest client ID${NC}"
fi

# Check for zombie process handling
ZOMBIE_HANDLED=$(grep "Child process .* terminated" test_logs/server_log.txt | wc -l)
echo -e "${YELLOW}Child process terminations handled: $ZOMBIE_HANDLED${NC}"

# Check for non-blocking behavior evidence
NON_BLOCKING=$(grep -E "No data yet|EAGAIN|EWOULDBLOCK" test_logs/client_*_log.txt | wc -l)
echo -e "${YELLOW}Evidence of non-blocking behavior: $NON_BLOCKING occurrences${NC}"

# Division by zero handling
DIV_ZERO_HANDLING=$(grep "Division by zero" test_logs/client_div_zero.txt 2>/dev/null | wc -l)
echo -e "${YELLOW}Division by zero handling: $DIV_ZERO_HANDLING occurrences${NC}"

# Summary of all test results
echo -e "${BLUE}=================================${NC}"
echo -e "${BLUE}Test Summary${NC}"
echo -e "${BLUE}=================================${NC}"

# Count success and failure indicators
SUCCESS_COUNT=0
FAILURE_COUNT=0

# Check for key success indicators
grep "Result received" test_logs/server_log.txt > /dev/null && ((SUCCESS_COUNT++))
grep "Task .* completed" test_logs/server_log.txt > /dev/null && ((SUCCESS_COUNT++))
grep "Server acknowledgment" test_logs/client_*_log.txt > /dev/null && ((SUCCESS_COUNT++))
grep "Calculated result" test_logs/client_*_log.txt > /dev/null && ((SUCCESS_COUNT++))
[ $CONCURRENT_CLIENTS -gt 1 ] && ((SUCCESS_COUNT++))
[ $ZOMBIE_HANDLED -gt 0 ] && ((SUCCESS_COUNT++))
[ $NON_BLOCKING -gt 0 ] && ((SUCCESS_COUNT++))
[ $EXIT_HANDLED -gt 0 ] && ((SUCCESS_COUNT++))

# Check for key failure indicators
grep "Failed to" test_logs/server_log.txt > /dev/null && ((FAILURE_COUNT++))
grep "Error:" test_logs/server_log.txt > /dev/null && ((FAILURE_COUNT++))
grep "Timeout waiting" test_logs/client_*_log.txt > /dev/null && ((FAILURE_COUNT++))
grep "Connection Failed" test_logs/client_*_log.txt > /dev/null && ((FAILURE_COUNT++))

# Print summary
echo -e "${GREEN}Success indicators found: $SUCCESS_COUNT${NC}"
echo -e "${RED}Failure indicators found: $FAILURE_COUNT${NC}"

if [ $FAILURE_COUNT -eq 0 ] && [ $SUCCESS_COUNT -gt 5 ]; then
    echo -e "${BLUE}=================================${NC}"
    echo -e "${GREEN}All tests passed successfully!${NC}"
    echo -e "${GREEN}Implementation meets all assignment requirements.${NC}"
    echo -e "${BLUE}=================================${NC}"
elif [ $FAILURE_COUNT -lt 2 ] && [ $SUCCESS_COUNT -gt 3 ]; then
    echo -e "${BLUE}=================================${NC}"
    echo -e "${YELLOW}Most tests passed with minor issues${NC}"
    echo -e "${YELLOW}Implementation mostly meets requirements but has some minor issues.${NC}"
    echo -e "${BLUE}=================================${NC}"
else
    echo -e "${BLUE}=================================${NC}"
    echo -e "${RED}Test completed with significant issues${NC}"
    echo -e "${RED}Implementation may not fully meet requirements.${NC}"
    echo -e "${BLUE}=================================${NC}"
fi

echo -e "${YELLOW}All test logs have been saved to the test_logs directory.${NC}"
echo -e "${YELLOW}Check these files for detailed information:${NC}"
echo "  - test_logs/server_log.txt: Server activity log"
echo "  - test_logs/client_*_log.txt: Individual client logs"
echo "  - test_logs/client_exit_test.txt: Exit command test log"
echo "  - test_logs/client_ack_test.txt: Acknowledgment test log"
echo "  - test_logs/client_timeout.txt: Timeout handling test log"
echo "  - test_logs/client_invalid_task.txt: Invalid task format test log"
echo "  - test_logs/division_zero_server.txt: Division by zero test server log"
echo "  - test_logs/client_div_zero.txt: Division by zero test client log"

# List all test logs
echo -e "${BLUE}=================================${NC}"
echo -e "${BLUE}All test log files:${NC}"
find test_logs -type f | sort
echo -e "${BLUE}=================================${NC}" > /dev/null && ((FAILURE_COUNT++))

# Print summary
echo -e "${GREEN}Success indicators found: $SUCCESS_COUNT${NC}"
echo -e "${RED}Failure indicators found: $FAILURE_COUNT${NC}"

if [ $FAILURE_COUNT -eq 0 ] && [ $SUCCESS_COUNT -gt 3 ]; then
    echo -e "${BLUE}=================================${NC}"
    echo -e "${GREEN}Test completed successfully!${NC}"
    echo -e "${BLUE}=================================${NC}"
else
    echo -e "${BLUE}=================================${NC}"
    echo -e "${YELLOW}Test completed with some concerns - check logs for details${NC}"
    echo -e "${BLUE}=================================${NC}"
fi

echo -e "${YELLOW}Note: Check the log files for more detailed information:${NC}"
echo "  - server_log.txt: Server activity log"
echo "  - client_*_log.txt: Individual client logs"
echo "  - client_exit_test.txt: Exit command test log"
echo "  - client_ack_test.txt: Acknowledgment test log"
echo "  - client_timeout.txt: Timeout handling test log"
echo "  - client_invalid_task.txt: Invalid task format test log"
echo "  - invalid_task_server.txt: Server log for invalid task test"